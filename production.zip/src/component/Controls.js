
import Button from "../component/Button"
import ActionButton from "./ActionButton";
const Controls ={
    Button,
    ActionButton
}

export default Controls;