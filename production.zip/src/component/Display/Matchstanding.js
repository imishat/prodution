import React from "react";

export default function Matchstanding() {
  return (
    <>
      <div
        style={{
          // background: "black",
          height: "231px",
          display: "flex",
          flexDirection: "column",
          // alignItems: "center",
        }}
      >
        <h2
          style={{
            position: "relative",
            left: "0px",
            color: "white",
            fontSize: "290px",
            fontFamily: "teko",
            marginTop: "-5px",
            marginLeft: "-25px",
            WebkitTextStrokeWidth: "1px",
            top: "-67px",
            WebkitTextStrokeColor: "white",
            color: "transparent",
            opacity: "67%",
          }}
        >
          MATCH STANDING
        </h2>
        <img
          style={{ position: "relative", left: "70px", top: "-385px" }}
          width="300px"
          src="https://media.discordapp.net/attachments/1067392894236905472/1086146168792305675/logo400.png"
          alt=""
        />
        <div
          style={{
            width: "1121px",
            position: "relative",
            left: "445px",
            top: "-595px",
            color: "white",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <div
            style={{
              display: "flex",
              fontFamily: "teko",
              fontWeight: "700px",
              justifyContent: "space-between",
              width: "884px",
            }}
          >
            <h2 style={{ fontSize: "40px" }}>
              PUBG MOBILE BATTLE OF THOUGHT SEASON 1
            </h2>
            <div
              style={{
                backgroundColor: "#187d5d",
                borderRadius: "4px",
                padding: "0px 10px",
              }}
            >
              <h2 style={{ fontSize: "40px" }}>QUALIFY ROUND M1/16</h2>
            </div>
          </div>
          <h2
            style={{
              fontFamily: "teko",
              fontWeight: "700",
              fontSize: "195px",
              marginTop: "-53px",
            }}
          >
            MATCH STANDING
          </h2>
        </div>
      </div>
      <div
        style={{
          display: "flex",
          alignContent: "center",
          position: "relative",
          top: "58px",
        }}
      >
        <div
          style={{
            height: "691px",
            width: "599px",
            position: "relative",
            left: "101px",
          }}
        >
          <div
            style={{
              height: "452.59px",
              backgroundColor: "rgba(0,0,0,0.5)",
              display: "flex",
              marginLeft: "20px",
              marginTop: "20px",
              clipPath:
                "polygon(0% 0%, 18.36% 0%, 20.03% 4%, 69.61% 4%, 70.95% 0%, 96.66% 0%, 100% 4.65%, 100% 25%, 97.66% 27.65%, 97.66% 41.81%, 100% 44.47%, 100% 100%, 0% 100%, 0% 34.96%, 1.34% 32.52%, 1.67% 13.94%, 0% 11.28%)",
            }}
          >
            <img
              height="375px"
              style={{ position: "relative", top: "78px", left: "-110px" }}
              src="https://media.discordapp.net/attachments/1067392894236905472/1085094239110692864/ar4.png?width=671&height=671"
              alt=""
            />
            <img
              height="375px"
              style={{ position: "relative", top: "78px", left: "-338px" }}
              src="https://media.discordapp.net/attachments/1067392894236905472/1085094240784220210/ar1.png?width=671&height=671"
              alt=""
            />
            <img
              height="375px"
              style={{ position: "relative", top: "78px", left: "-436px" }}
              src="https://media.discordapp.net/attachments/1067392894236905472/1085094240784220210/ar1.png?width=671&height=671"
              alt=""
            />
            <img
              height="375px"
              style={{ position: "relative", top: "78px", left: "-957px" }}
              src="https://media.discordapp.net/attachments/1067392894236905472/1085094240784220210/ar1.png?width=671&height=671"
              alt=""
            />
          </div>
          <div
            style={{
              height: "119.2px",
              backgroundColor: "#c0c0c0",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              width: "583px",
              position: "relative",
              left: "16px",
              padding: "0px 15px",
              clipPath:
                "polygon(0% 0%, 100% 0%, 100% 21.01%, 98.33% 31.93%, 98.33% 70.59%, 100% 80.67%, 100% 100%, 0% 100%, 0% 88.24%, 1.17% 84.03%, 1.17% 68.91%, 0% 63.87%)",
            }}
          >
            <img
              height="93px"
              src="https://media.discordapp.net/attachments/894821411548446800/1041889351392563220/tie2_png.png?width=671&height=671"
              alt=""
            />
            <h2
              style={{
                fontFamily: "teko",
                fontSize: "63px",
                fontWeight: "600",
                position: "relative",
                top: "8px",
              }}
            >
              TAKE IT EASYS
            </h2>
            <img
              height="68px"
              src="https://media.discordapp.net/attachments/1067392894236905472/1089620008574914691/Flag_of_Nepal.svg.png?width=550&height=671"
              alt=""
            />
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-evenly",
              height: "119px",
              clipPath:
                "polygon(0% 0%, 100% 0%, 100% 100%, 81.8% 100%, 80.63% 90.76%, 59.27% 90.76%, 57.6% 100%, 3.34% 100%, 0% 84.03%)",
              backgroundColor: "white",
            }}
          >
            <div style={{ textAlign: "center" }}>
              <h2>1</h2>
              <h2>PLACE</h2>
            </div>
            <div style={{ textAlign: "center" }}>
              <h2>15</h2>
              <h2>RANK PTS</h2>
            </div>
            <div style={{ textAlign: "center" }}>
              <h2>10</h2>
              <h2>ELIMS</h2>
            </div>
            <div style={{ textAlign: "center" }}>
              <h2>25</h2>
              <h2>TOTAL PTS</h2>
            </div>
          </div>
        </div>
        <div style={{ position: "relative", left: "179px", top: "14px" }}>
          <table
            style={{ borderCollapse: "separate", borderSpacing: "3px" }}
            class="  "
          >
            <thead>
              <tr>
                <th
                  style={{
                    width: "110px",
                    height: "38px",
                    textAlign: "center",
                    backgroundColor: "black",
                    color: "white",
                    clipPath:
                      "polygon(10.91% 0%, 100% 0%, 100% 100%, 0% 100%, 0% 22.41%)",
                  }}
                  scope="col"
                >
                  RANK
                </th>
                <th
                  style={{
                    width: "529px",
                    height: "38px",
                    textAlign: "center",
                    backgroundColor: "black",
                    color: "white",
                    clipPath:
                      "polygon(0% 0%, 7.56% 0%, 8.88% 13.79%, 31.76% 13.79%, 32.7% 0%, 70.13% 0%, 71.27% 13.79%, 89.22% 13.79%, 90.36% 0%, 100% 0%, 100% 100%, 0% 100%)",
                  }}
                  scope="col"
                >
                  TEAM NAME
                </th>
                <th
                  style={{
                    width: "104px",
                    height: "38px",
                    textAlign: "center",
                    backgroundColor: "#007B56",
                    color: "white",
                  }}
                  scope="col"
                >
                  PLACE
                </th>
                <th
                  style={{
                    width: "104px",
                    height: "38px",
                    textAlign: "center",
                    backgroundColor: "#007B56",
                    color: "white",
                  }}
                  scope="col"
                >
                  RANK PTS
                </th>
                <th
                  style={{
                    width: "104px",
                    height: "38px",
                    textAlign: "center",
                    backgroundColor: "#007B56",
                    color: "white",
                  }}
                  scope="col"
                >
                  ELMS
                </th>
                <th
                  style={{
                    width: "105px",
                    height: "38px",
                    textAlign: "center",
                    backgroundColor: "#007B56",
                    color: "white",
                    clipPath:
                      "polygon(0% 0%, 88.46% 0%, 100% 20.34%, 100% 100%, 0% 100%)",
                  }}
                  scope="col"
                >
                  TOTAL PTS
                </th>
              </tr>
            </thead>

            <tbody>
              <tr
                style={{
                  height: "48px",
                  textAlign: "center",
                  verticalAlign: "middle",
                  fontFamily: "teko",
                  fontWeight: "bold",
                  fontSize: "32px",
                  background: "rgba(216, 216, 216, 0.3)",
                }}
              >
                <th
                  style={{
                    padding: "0px",
                    background: "rgba(158, 158, 158, 0.7)",
                    color: "white",
                  }}
                  scope="row"
                >
                  #2
                </th>
                <td
                  style={{
                    display: "flex",
                    alignItems: "center",
                    textAlign: "center",
                    padding: "0px",
                  }}
                >
                  <div
                    style={{
                      width: "112px",
                      background: "rgba(256,256,256,0.7",
                      padding: "0px",
                    }}
                  >
                    <img
                      height="38.78px"
                      width="38.78px"
                      src="https://media.discordapp.net/attachments/894821411548446800/1041889351392563220/tie2_png.png?width=671&height=671"
                      alt=""
                    />
                  </div>
                  <div
                    style={{
                      display: "flex",
                      gap: "41px",
                      alignItems: "center",
                    }}
                  >
                    <div style={{}}>
                      <img
                        height="30px"
                        width="35px"
                        style={{ padding: "3px",marginLeft:"5px" }}
                        src="https://media.discordapp.net/attachments/1067392894236905472/1089620008574914691/Flag_of_Nepal.svg.png?width=550&height=671"
                        alt=""
                      />
                    </div>
                    <h2
                      style={{
                        fontFamily: "teko",
                        position: "relative",
                        top: "7px",
                        fontWeight: "bolder",
                        color: "white",
                      }}
                    >
                      TAKE IT EASY
                    </h2>
                    {""}
                  </div>
                </td>

                <td style={{ padding: "0px" }}>0</td>
                <td style={{ padding: "0px" }}>0</td>
                <td style={{ padding: "0px" }}>0</td>
                <td style={{ padding: "0px" }}>0</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
