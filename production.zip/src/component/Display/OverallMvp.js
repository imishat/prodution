
import React from 'react'

export default function OverallMvp() {
  return (
   <>
      <div
        style={{
            //  background:"black",
          height: "231px",
          display: "flex",
          flexDirection:"column",
          // alignItems: "center",
        }}
      >
       <h2 style={{ position: "relative", left: "0px", color: "white", fontSize: "220px", fontFamily: "teko", marginTop: "-5px", marginLeft: "-25px", WebkitTextStrokeWidth: "1px", top:"-43px",
  WebkitTextStrokeColor: "white",
  color: "transparent",opacity:"67%"}}>
       EVENT MOST VALUEABLE PLAYER
      </h2>
        <img
          style={{ position: "relative", left: "70px",top:"-302px" }}
          width="300px"
          src="https://media.discordapp.net/attachments/1067392894236905472/1086146168792305675/logo400.png"
          alt=""
        />
      
      </div>
      <div style={{display:"flex",justifyContent:"center",alignItems:"center",position:"relative",top:"-176px",left:"-110px"}}>
       
        {/* FOR STATS */}
        <div style={{height:"646px",width:"1125px",display:"flex",alignItems:"center",flexDirection:"column",position:'relative',left:"387px"}}>
            <h2 style={{width:"1125px",fontFamily:"teko",fontWeight:"bold",fontSize:"99px",height:"95px",color:"white"}}>EVENT MATCH MOST VALUEABLE PLAYER</h2>
            <h1 style={{width:"1125px",fontFamily:"impact",fontSize:"612px",height:"397px",textAlign:'center',position:'relative',top:"-139px",left:"-49px",color:"white"}}>MVP</h1>
            <h2 style={{height:"177px",width:"1040px", left:"-36px", backgroundColor:"white",position:"relative",fontFamily:'teko',fontWeight:'bolder',textAlign:"center",top:"75px",fontSize:"70px",clipPath:"polygon(2.24% 0%, 100% 0%, 100% 100%, 0% 100%, 0% 16.38%)",color:"#187d5d"}}>TIE AADITYA</h2>
            <h2 style={{height:"70px",width:"1040px", left:"-36px", backgroundColor:"#187d5d",position:"relative",fontFamily:'teko',fontWeight:'bolder',textAlign:"center",top:"68px",fontSize:"70px",clipPath:"polygon(0% 0%, 100% 0%, 100% 70.95%, 97.28% 100%, 91.92% 100%, 89.77% 89.03%, 66.96% 89.03%, 64.72% 100%, 0% 100%)",color:"white"}}>DREAM TO DESTINATION</h2>

        <img width="200px" height="200px" style={{position:"relative",top:"-119px",left:"353px"}} src="https://media.discordapp.net/attachments/894821411548446800/1041889351392563220/tie2_png.png?width=671&height=671" alt="" />
            
            
        </div>
        {/* FOR IMAGe */}
        <div style={{position:"relative"}}>
        <img height="1029px" width="934px" src="https://media.discordapp.net/attachments/1067392894236905472/1067435963984396288/12.png?width=604&height=604" alt="" />
        </div>
      </div>
   </>
  )
}
