import React from 'react'

export default function Schedule() {
  return (
   <>
    
    <div
        style={{
            //  background:"black",
          height: "231px",
          display: "flex",
          flexDirection:"column",
          // alignItems: "center",
        }}
      >
       <h2 style={{ position: "relative", left: "0px", color: "white", fontSize: "290px", fontFamily: "teko", marginTop: "-5px", marginLeft: "-25px", WebkitTextStrokeWidth: "1px", top:"-67px",
  WebkitTextStrokeColor: "white",
  color: "transparent",opacity:"67%"}}>
        TODAYS'S SCHEDULE
      </h2>
        <img
          style={{ position: "relative", left: "70px",top:"-385px" }}
          width="300px"
          src="https://media.discordapp.net/attachments/1067392894236905472/1086146168792305675/logo400.png"
          alt=""
        />
       <div style={{width:"1121px",position:"relative",left:"445px",top:"-595px",color:"white",display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center"}}>
        <div style={{display:"flex",fontFamily:'teko',fontWeight:"700px",justifyContent:"space-between",width:"884px"}} >
        <h2 style={{fontSize:"40px"}}>PUBG MOBILE BATTLE OF THOUGHT SEASON 1</h2>
        <div style={{backgroundColor:"#187d5d",borderRadius:"4px",padding:"0px 10px"}}>

        <h2 style={{fontSize:"40px"}}>QUALIFY ROUND M1/16</h2>
        </div>

        </div>
        <h2 style={{fontFamily:"teko",fontWeight:"700",fontSize:"176px",marginTop:"-42px"}}>TODAY'S SCHEDULE</h2>
       </div>
      </div>
      <div style={{margin:"151px 72px",display:"flex"}}>
        {/* MATCH-1 */}
        <div style={{height:"563px",width:"380px",margin:"0px 28px"}}> 
          <div style={{height:"87px",background:"black",textAlign:"center",fontSize:"50px",fontWeight:"500",color:"white",fontFamily:"Teko",clipPath:"polygon(0% 0.32%, 28.4% 0.32%, 30.19% 6.07%, 63.6% 5.37%, 65.43% 0.32%, 96.05% 0.32%, 100% 19.35%, 100% 44.09%, 98.02% 50.16%, 98.02% 70.91%, 100% 77.42%, 100% 100%, 2.58% 100%, 0% 89.25%, 0% 56.77%, 1.77% 51.34%, 1.77% 26.6%, 0% 19.35%)"}}>
            <p style={{paddingTop:"10px"}}>MATCH 1</p>
          </div>
          <div style={{height:"416px",clipPath:"polygon(0% 0%, 100.25% 0%, 100% 17.52%, 97.98% 19.19%, 97.98% 53.66%, 100% 55.65%, 100.25% 100.22%, 0% 100.22%, 0% 72.34%, 1.97% 71.4%, 1.97% 56.76%, 0% 54.77%)"}}>
            <img height="416px" src="https://media.discordapp.net/attachments/1067392894236905472/1067396758101033070/ERANGEL.png" alt="" />
            <p style={{position:"relative",bottom:"45px",left:"136px",color:"white",fontFamily:"Teko",fontSize:"45px"}}>ERANGEL</p>
          </div>
          <div style={{background:"#c1c1c1",height:"61px",textAlign:"center",fontSize:"50px",fontWeight:"600",color:"black",fontFamily:"Teko",clipPath:"polygon(0% 0%, 100% 0%, 100% 100%, 83.99% 100%, 83% 92.42%, 51.23% 92.42%, 50% 100%, 2.46% 100%, 0% 84.47%)"}}>
            <p>WWCD</p>
          </div>
        </div>
        {/* MATCH-2 */}
        <div style={{height:"563px",width:"380px",margin:"0px 28px"}}> 
          <div style={{height:"87px",background:"black",textAlign:"center",fontSize:"50px",fontWeight:"500",color:"white",fontFamily:"Teko",clipPath:"polygon(0% 0.32%, 28.4% 0.32%, 30.19% 6.07%, 63.6% 5.37%, 65.43% 0.32%, 96.05% 0.32%, 100% 19.35%, 100% 44.09%, 98.02% 50.16%, 98.02% 70.91%, 100% 77.42%, 100% 100%, 2.58% 100%, 0% 89.25%, 0% 56.77%, 1.77% 51.34%, 1.77% 26.6%, 0% 19.35%)"}}>
            <p style={{paddingTop:"10px"}}>MATCH 2</p>
          </div>
          <div style={{height:"416px",clipPath:"polygon(0% 0%, 100.25% 0%, 100% 17.52%, 97.98% 19.19%, 97.98% 53.66%, 100% 55.65%, 100.25% 100.22%, 0% 100.22%, 0% 72.34%, 1.97% 71.4%, 1.97% 56.76%, 0% 54.77%)"}}>
            <img height="416px" src="https://media.discordapp.net/attachments/1067392894236905472/1067396757815828601/MIRAMAR.png" alt="" />
            <p style={{position:"relative",bottom:"45px",left:"136px",color:"white",fontFamily:"Teko",fontSize:"45px"}}>MIRAMAR</p>
          </div>
          <div style={{background:"#c1c1c1",height:"61px",textAlign:"center",fontSize:"50px",fontWeight:"600",color:"black",fontFamily:"Teko",clipPath:"polygon(0% 0%, 100% 0%, 100% 100%, 83.99% 100%, 83% 92.42%, 51.23% 92.42%, 50% 100%, 2.46% 100%, 0% 84.47%)"}}>
            <p>WWCD</p>
          </div>
        </div>
        {/* MATCH-3 */}
        <div style={{height:"563px",width:"380px",margin:"0px 28px"}}> 
          <div style={{height:"87px",background:"black",textAlign:"center",fontSize:"50px",fontWeight:"500",color:"white",fontFamily:"Teko",clipPath:"polygon(0% 0.32%, 28.4% 0.32%, 30.19% 6.07%, 63.6% 5.37%, 65.43% 0.32%, 96.05% 0.32%, 100% 19.35%, 100% 44.09%, 98.02% 50.16%, 98.02% 70.91%, 100% 77.42%, 100% 100%, 2.58% 100%, 0% 89.25%, 0% 56.77%, 1.77% 51.34%, 1.77% 26.6%, 0% 19.35%)"}}>
            <p style={{paddingTop:"10px"}}>MATCH 3</p>
          </div>
          <div style={{height:"416px",clipPath:"polygon(0% 0%, 100.25% 0%, 100% 17.52%, 97.98% 19.19%, 97.98% 53.66%, 100% 55.65%, 100.25% 100.22%, 0% 100.22%, 0% 72.34%, 1.97% 71.4%, 1.97% 56.76%, 0% 54.77%)"}}>
            <img height="416px" src="https://media.discordapp.net/attachments/1067392894236905472/1067396757589332008/SANHOK.png" alt="" />
            <p style={{position:"relative",bottom:"45px",left:"136px",color:"white",fontFamily:"Teko",fontSize:"45px"}}>SHANOK</p>
          </div>
          <div style={{background:"#c1c1c1",height:"61px",textAlign:"center",fontSize:"50px",fontWeight:"600",color:"black",fontFamily:"Teko",clipPath:"polygon(0% 0%, 100% 0%, 100% 100%, 83.99% 100%, 83% 92.42%, 51.23% 92.42%, 50% 100%, 2.46% 100%, 0% 84.47%)"}}>
            <p>WWCD</p>
          </div>
        </div>
        {/* MATCH-4 */}
        <div style={{height:"563px",width:"380px",margin:"0px 28px"}}> 
          <div style={{height:"87px",background:"black",textAlign:"center",fontSize:"50px",fontWeight:"500",color:"white",fontFamily:"Teko",clipPath:"polygon(0% 0.32%, 28.4% 0.32%, 30.19% 6.07%, 63.6% 5.37%, 65.43% 0.32%, 96.05% 0.32%, 100% 19.35%, 100% 44.09%, 98.02% 50.16%, 98.02% 70.91%, 100% 77.42%, 100% 100%, 2.58% 100%, 0% 89.25%, 0% 56.77%, 1.77% 51.34%, 1.77% 26.6%, 0% 19.35%)"}}>
            <p style={{paddingTop:"10px"}}>MATCH 4</p>
          </div>
          <div style={{height:"416px",clipPath:"polygon(0% 0%, 100.25% 0%, 100% 17.52%, 97.98% 19.19%, 97.98% 53.66%, 100% 55.65%, 100.25% 100.22%, 0% 100.22%, 0% 72.34%, 1.97% 71.4%, 1.97% 56.76%, 0% 54.77%)"}}>
            <img height="416px" src="https://media.discordapp.net/attachments/1067392894236905472/1067396758101033070/ERANGEL.png" alt="" />
            <p style={{position:"relative",bottom:"45px",left:"136px",color:"white",fontFamily:"Teko",fontSize:"45px"}}>ERANGEL</p>
          </div>
          <div style={{background:"#c1c1c1",height:"61px",textAlign:"center",fontSize:"50px",fontWeight:"600",color:"black",fontFamily:"Teko",clipPath:"polygon(0% 0%, 100% 0%, 100% 100%, 83.99% 100%, 83% 92.42%, 51.23% 92.42%, 50% 100%, 2.46% 100%, 0% 84.47%)"}}>
            <p>WWCD</p>
          </div>
        </div>
      </div>
   </>
  )
}
