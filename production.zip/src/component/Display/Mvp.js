
import React from 'react'

export default function Mvp() {
  return (
   <>
      <div
        style={{
            // background:"black",
          height: "231px",
          display: "flex",
          flexDirection:"column",
          // alignItems: "center",
        }}
      >
       <h2 style={{ position: "relative", left: "0px", color: "white", fontSize: "290px", fontFamily: "teko", marginTop: "-5px", marginLeft: "-25px", WebkitTextStrokeWidth: "1px", top:"-67px",
  WebkitTextStrokeColor: "white",
  color: "transparent",opacity:"67%"}}>
        MOST VALUEABLE PLAYER
      </h2>
        <img
          style={{ position: "relative", left: "70px",top:"-385px" }}
          width="300px"
          src="https://media.discordapp.net/attachments/1067392894236905472/1086146168792305675/logo400.png"
          alt=""
        />
      
      </div>
      <div style={{display:"flex",position:"relative",top:"-162px",left:"30px"}}>
        {/* FOR IMAGe */}
        <div>
        <img height="1029px" width="934px" src="https://media.discordapp.net/attachments/1067392894236905472/1067435963984396288/12.png?width=604&height=604" alt="" />
        </div>
        {/* FOR STATS */}
        <div style={{height:"889px",width:"905px",display:"flex",alignItems:"center",flexDirection:"column"}}>
            <h2 style={{width:"905px",fontFamily:"teko",fontWeight:"bold",fontSize:"99px",height:"58px",color:"white"}}>MATCH MOST VALUEABLE PLAYER</h2>
            <h1 style={{width:"900px",fontFamily:"impact",fontSize:"501px",height:"303px",textAlign:'center',position:'relative',top:"-73px",left:"-31px",color:"white"}}>MVP</h1>
            <h3 style={{zIndex:"0",position:'relative',height:"49px",width:"295px",backgroundColor:"#008930",fontFamily:"teko",textAlign:"center",fontSize:"48px",fontWeight:'bold',top:'15px',left:"129px",color:"white"}}>GRAND-FINAL 01/08</h3>
            <h2 style={{height:"70px",width:"828px", left:"-32px", backgroundColor:"#187d5d",position:"relative",fontFamily:'teko',fontWeight:'bolder',textAlign:"center",top:"65px",fontSize:"70px",clipPath:"polygon(1.56% 0%, 81.11% 0%, 81.69% 12.86%, 93% 12.86%, 93.44% 0%, 100% 0%, 100% 71.89%, 97.22% 100%, 21.67% 100%, 20.44% 91.84%, 9.46% 91.84%, 7.89% 100%, 0% 101.43%, 0% 21.43%)",color:"white"}}>TIE AADITYA</h2>
            <div style={{position:'relative',height:"253px",width:"900px",display:"flex",alignItems:"center",top:"42px"}}>
              
                <img height="253px" width="264px" src="https://media.discordapp.net/attachments/894821411548446800/1041889351392563220/tie2_png.png?width=604&height=604" alt="" />
                <h2 style={{fontFamily:"teko",fontWeight:"bold",fontSize:"77px",marginLeft:"31px",color:"white"}}>TAKE IT EASY</h2>
            </div>
            <div style={{display:"flex",width:"828px",position:"relative",left:"-32px",marginTop:"18px" }}  >
              <div style={{height:"85px",width:"410px",display:"flex",marginRight:"10px" }} >
                  <h2 style={{width:"341px",backgroundColor:"#187d5d",textAlign:"center",clipPath:"polygon(4.68% 0%, 67.54% 0%, 69.59% 8.14%, 86.26% 8.14%, 88.01% 0%, 99.71% 0%, 99.71% 98.84%, 69.59% 98.84%, 67.54% 89.54%, 48.43% 89.54%, 46.19% 98.84%, 0% 98.84%, 0% 18.6%)",display:"flex",justifyContent:"center",alignItems:"center",fontWeight:"bold",fontsize:"30px",color:"white"}}> MATCH KILLS </h2>
                  <h2 style={{width:"103px",backgroundColor:"white",textAlign:"center",clipPath:"polygon(0% 0%, 83.65% 0%, 100% 16.28%, 100% 100%, 0% 100%)",display:"flex",justifyContent:"center",alignItems:"center",fontWeight:"bold",fontsize:"30px",position:"relative",left:"-1px"}}> 0</h2>
              </div>
              <div style={{height:"85px",width:"410px",display:"flex"}} >
                  <h2 style={{width:"341px",backgroundColor:"#187d5d",textAlign:"center",clipPath:"polygon(4.68% 0%, 67.54% 0%, 69.59% 8.14%, 86.26% 8.14%, 88.01% 0%, 99.71% 0%, 99.71% 98.84%, 69.59% 98.84%, 67.54% 89.54%, 48.43% 89.54%, 46.19% 98.84%, 0% 98.84%, 0% 18.6%)",display:"flex",justifyContent:"center",alignItems:"center",fontWeight:"bold",fontsize:"30px",color:"white"}}> CONTIBUTION </h2>
                  <h2 style={{width:"103px",backgroundColor:"white",textAlign:"center",clipPath:"polygon(0% 0%, 83.65% 0%, 100% 16.28%, 100% 100%, 0% 100%)",display:"flex",justifyContent:"center",alignItems:"center",fontWeight:"bold",fontsize:"30px",position:"relative",left:"-1px"}}> 0</h2>
              </div>
             
            </div>
            <div style={{display:"flex",width:"828px",position:"relative",left:"-32px",marginTop:"10px" }}  >
              <div style={{height:"85px",width:"410px",display:"flex",marginRight:"10px" }} >
                  <h2 style={{width:"341px",backgroundColor:"#187d5d",textAlign:"center",clipPath:"polygon(4.68% 0%, 67.54% 0%, 69.59% 8.14%, 86.26% 8.14%, 88.01% 0%, 99.71% 0%, 99.71% 98.84%, 69.59% 98.84%, 67.54% 89.54%, 48.43% 89.54%, 46.19% 98.84%, 0% 98.84%, 0% 18.6%)",display:"flex",justifyContent:"center",alignItems:"center",fontWeight:"bold",fontsize:"30px",color:"white"}}> OVERALL KILLS </h2>
                  <h2 style={{width:"103px",backgroundColor:"white",textAlign:"center",clipPath:"polygon(0% 0%, 83.65% 0%, 100% 16.28%, 100% 100%, 0% 100%)",display:"flex",justifyContent:"center",alignItems:"center",fontWeight:"bold",fontsize:"30px",position:"relative",left:"-1px"}}> 0</h2>
              </div>
              <div style={{height:"85px",width:"410px",display:"flex"}} >
                  <h2 style={{width:"341px",backgroundColor:"#187d5d",textAlign:"center",clipPath:"polygon(4.68% 0%, 67.54% 0%, 69.59% 8.14%, 86.26% 8.14%, 88.01% 0%, 99.71% 0%, 99.71% 98.84%, 69.59% 98.84%, 67.54% 89.54%, 48.43% 89.54%, 46.19% 98.84%, 0% 98.84%, 0% 18.6%)",display:"flex",justifyContent:"center",alignItems:"center",fontWeight:"bold",fontsize:"30px",color:"white"}}> OVERALL RANKING </h2>
                  <h2 style={{width:"103px",backgroundColor:"white",textAlign:"center",clipPath:"polygon(0% 0%, 83.65% 0%, 100% 16.28%, 100% 100%, 0% 100%)",display:"flex",justifyContent:"center",alignItems:"center",fontWeight:"bold",fontsize:"30px",position:"relative",left:"-1px"}}> 0</h2>
              </div>
             
            </div>
        </div>
      </div>
   </>
  )
}
