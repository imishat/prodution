import { createContext } from "react";

const AddteamContext = createContext();

export default AddteamContext;