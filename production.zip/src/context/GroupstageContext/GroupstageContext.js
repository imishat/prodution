import { createContext } from "react";

const GroupstageContext = createContext();

export default GroupstageContext;