import { createContext } from "react";

const TallyContext = createContext();

export default TallyContext;