import { createContext } from "react";

const TournamentContext = createContext();

export default TournamentContext;