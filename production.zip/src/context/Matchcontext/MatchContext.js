import { createContext } from "react";

const MatchContext = createContext();

export default MatchContext;